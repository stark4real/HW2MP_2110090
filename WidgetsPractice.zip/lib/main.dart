import 'package:flutter/material.dart';
import 'greeting_widget.dart';
import 'counter_widget.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: Text('One Piece App'),
        ),
        body: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            GreetingWidget('Welcome to the One Piece App!'),
            SizedBox(height: 32),
            CounterWidget(),
            SizedBox(height: 32),
            Container(
              padding: EdgeInsets.all(16),
              color: Colors.grey[200],
              child: Column(
                children: [
                  Text(
                    'Widget Tree Example',
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 8),
                  GreetingWidget(
                    'Hello from the world of One Piece!',
                  ),
                  SizedBox(height: 16),
                  CounterWidget(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
