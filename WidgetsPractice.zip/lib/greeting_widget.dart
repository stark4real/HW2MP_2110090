import 'package:flutter/material.dart';

class GreetingWidget extends StatelessWidget {
  final String greeting;

  GreetingWidget(this.greeting);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Text(
        greeting,
        style: TextStyle(
          fontSize: 24,
          color: Colors.blue,
          fontFamily: 'OnePieceFont',
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}
