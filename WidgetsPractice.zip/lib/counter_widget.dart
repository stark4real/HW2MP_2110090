import 'package:flutter/material.dart';

class CounterWidget extends StatefulWidget {
  @override
  _CounterWidgetState createState() => _CounterWidgetState();
}

class _CounterWidgetState extends State<CounterWidget> {
  int counter = 0;

  void _incrementCounter() {
    setState(() {
      counter++;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          'Counter Value: $counter',
          style: TextStyle(
            fontSize: 24,
            color: Colors.red,
            fontWeight: FontWeight.bold,
          ),
        ),
        SizedBox(height: 16),
        ElevatedButton(
          onPressed: _incrementCounter,
          style: ElevatedButton.styleFrom(
            primary: Colors.orange, // Button color
            onPrimary: Colors.white, // Text color
          ),
          child: Text('Increment'),
        ),
      ],
    );
  }
}
